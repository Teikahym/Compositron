﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WMPLib;

namespace Compositron
{
    /// <summary>
    /// Interaction logic for play.xaml
    /// </summary>
    public partial class play : Window
    {
        public play()
        {
            InitializeComponent();
        }
        public string filename;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            WindowsMediaPlayer wmp = new WindowsMediaPlayer();
            wmp.URL = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, filename);
            slider_duration.Maximum = wmp.controls.currentItem.duration;
            slider_duration.Value = wmp.controls.currentPosition;
            wmp.controls.play();
        }
    }
}
