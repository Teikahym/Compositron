﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Shapes;
using System.IO;
using System.Net;
using WMPLib;
using Microsoft.Win32;
using System.Windows.Media.Animation;
using System.Windows.Interop;
using System.Windows.Controls;
using System.Windows.Media;
using System.Collections.Generic;
using System.Windows.Media.Imaging;

namespace Compositron
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            wmp.PlayStateChange += new WMPLib._WMPOCXEvents_PlayStateChangeEventHandler(wplayer_PlayStateChange);
        }

        public static System.Windows.Media.Effects.Effect[] Shadows = new System.Windows.Media.Effects.Effect[5];

        string filename;
        WindowsMediaPlayer wmp = new WindowsMediaPlayer();

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            // Begin dragging the window
            this.DragMove();
        }
        
        private void Generation_Button_Click(object sender, RoutedEventArgs e)
        {
            Play.IsEnabled = false;
            Save.IsEnabled = false;
            wmp.controls.stop();
            Play.Content = "Play";
            if (Inspiration_enabled.IsChecked == true)
            {
                try
                {
                    filename = slider_temp.Value.ToString().Split(',')[0] + "." + slider_temp.Value.ToString().Split(',')[1] + "_" + slider_seed.Value + "_" + slider_length.Value + "_" + inspiration_path.Text.Split('\\')[inspiration_path.Text.Split('\\').Length -1];
                }
                catch (Exception)
                {
                    filename = slider_temp.Value + "_" + slider_seed.Value + "_" + slider_length.Value + "_" + inspiration_path.Text.Split('\\')[inspiration_path.Text.Split('\\').Length - 1];
                }
            }
            else
            {
                try
                {
                    filename = slider_temp.Value.ToString().Split(',')[0] + "." + slider_temp.Value.ToString().Split(',')[1] + "_" + slider_seed.Value + "_" + slider_length.Value;
                }
                catch (Exception)
                {
                    filename = slider_temp.Value + "_" + slider_seed.Value + "_" + slider_length.Value;
                }
            }
            if(Check_for_Completion())
            {

                if (new FileInfo(System.AppDomain.CurrentDomain.BaseDirectory + filename + "_" + Template_Name.Content + ".mid").Length > 100)
                {
                    Play.IsEnabled = true;
                    Save.IsEnabled = true;
                    File.Delete(filename);
                }
                else
                {
                    no_content nocontent = new no_content();
                    nocontent.Left = this.Left + (this.Width / 2f) - (nocontent.Width / 2f);
                    nocontent.Top = this.Top + (this.Height / 2f) - (nocontent.Height / 2f);
                    this.Effect = (System.Windows.Media.Effects.Effect)this.FindResource("blur");
                    nocontent.ShowDialog();
                    this.Effect = null;
                }

            }
            else
            {
                FtpWebResponse response = null;
                FtpWebRequest request = null;
                try
                {
                    if(Inspiration_enabled.IsChecked == true)
                    {
                        try
                        {
                            FtpWebRequest request1 = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/" + Template_Name.Content + "/pre_mid/" + inspiration_path.Text.Split('\\')[inspiration_path.Text.Split('\\').Length - 1]);
                            // Get the object used to communicate with the server.

                            request1.Method = WebRequestMethods.Ftp.UploadFile;

                            // This example assumes the FTP site uses anonymous logon.
                            request1.Credentials = new NetworkCredential("anonymous", "this");

                            StreamReader sourceStream1 = new StreamReader(inspiration_path.Text);
                            byte[] fileContents1 = Encoding.UTF8.GetBytes(sourceStream1.ReadToEnd());
                            sourceStream1.Close();
                            request1.ContentLength = fileContents1.Length;

                            Stream requestStream1 = request1.GetRequestStream();
                            requestStream1.Write(fileContents1, 0, fileContents1.Length);
                            requestStream1.Close();

                            FtpWebResponse response1 = (FtpWebResponse)request1.GetResponse();

                            Console.WriteLine("Upload File Complete, status {0}", response1.StatusDescription);
                            response1.Close();

                        }
                        catch(Exception exc){ }

                        request = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/" + Template_Name.Content + "/pre_requests/" + filename);
                    }
                    else
                    {
                        request = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/" + Template_Name.Content + "/requests/" + filename);
                    }
                    // Get the object used to communicate with the server.
                     
                    request.Method = WebRequestMethods.Ftp.UploadFile;

                    // This example assumes the FTP site uses anonymous logon.
                    request.Credentials = new NetworkCredential("anonymous", "this");

                    // Copy the contents of the file to the request stream.
                    File.Create(filename).Close();

                    StreamReader sourceStream = new StreamReader(filename);
                    byte[] fileContents = Encoding.UTF8.GetBytes(sourceStream.ReadToEnd());
                    sourceStream.Close();
                    request.ContentLength = fileContents.Length;

                    Stream requestStream = request.GetRequestStream();
                    requestStream.Write(fileContents, 0, fileContents.Length);
                    requestStream.Close();

                    response = (FtpWebResponse)request.GetResponse();

                    Console.WriteLine("Upload File Complete, status {0}", response.StatusDescription);
                    response.Close();
                    Generating_Window();
                }
                catch(WebException es)
                {
                    if (es.Status == WebExceptionStatus.ConnectFailure)
                    {
                        MessageBox.Show("Compositron Server unavailable");
                    }
                }
            }
        }

        private void Generating_Window()
        {
            generating new_subject_window = new generating();

            var location = this.PointToScreen(new Point(0, 0));
            new_subject_window.Left = this.Left + (this.Width / 2f) - (new_subject_window.Width / 2f);
            new_subject_window.Top = this.Top + (this.Height / 2f) - (new_subject_window.Height / 2f);

            this.Effect = (System.Windows.Media.Effects.Effect)this.FindResource("blur");

            new_subject_window.Show();
            while (!Check_for_Completion()){ System.Threading.Thread.Sleep(250); }

            if (new FileInfo(System.AppDomain.CurrentDomain.BaseDirectory + filename + "_" + Template_Name.Content + ".mid").Length > 100)
            {
                new_subject_window.Close();
                this.Effect = null;
                Play.IsEnabled = true;
                Save.IsEnabled = true;
            }
            else
            {
                new_subject_window.Close();
                no_content nocontent = new no_content();
                nocontent.Left = this.Left + (this.Width / 2f) - (nocontent.Width / 2f);
                nocontent.Top = this.Top + (this.Height / 2f) - (nocontent.Height / 2f);
                this.Effect = (System.Windows.Media.Effects.Effect)this.FindResource("blur");
                nocontent.ShowDialog();
                this.Effect = null;
            }
        }

        private bool Check_for_Completion()
        {
            // Get the object used to communicate with the server.
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/" + Template_Name.Content + @"/response/" + filename + ".mid");
            request.Method = WebRequestMethods.Ftp.DownloadFile;

            // This example assumes the FTP site uses anonymous logon.
            request.Credentials = new NetworkCredential("anonymous", "beta-01");
            try
            {
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                Stream reader = response.GetResponseStream();
                FileStream fileStream = new FileStream(filename + "_" + Template_Name.Content + ".mid", FileMode.Create);
                int bytesRead = 0;
                byte[] buffer = new byte[2048];
                while (true)
                {
                    bytesRead = reader.Read(buffer, 0, buffer.Length);

                    if (bytesRead == 0)
                        break;

                    fileStream.Write(buffer, 0, bytesRead);
                }
                fileStream.Close();

                Console.WriteLine("Download Complete, status {0}", response.StatusDescription);

                reader.Close();
                response.Close();
                return true;
            }
            catch (Exception)
            { System.Threading.Thread.Sleep(1000); }
            return false;
        }

        private void Play_Click(object sender, RoutedEventArgs e)
        {
            if (wmp.playState == WMPPlayState.wmppsPlaying)
            {
                Play.Content = "Play";
                wmp.controls.stop();
            }
            else
            {
                wmp.URL = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, filename + "_" + Template_Name.Content + ".mid");
                wmp.controls.play();
                Play.Content = "Stop";
            }
        }

        void wplayer_PlayStateChange(int NewState)
        {
            if (NewState == (int)WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                Play.Content = "Play";
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog savedialog = new SaveFileDialog();
            savedialog.FileName = filename + "_" + Template_Name.Content + ".mid";
            savedialog.Filter = "MIDI file (*.mid)|*.mid";
            if (savedialog.ShowDialog() == true)
                File.Copy(filename + "_" + Template_Name.Content + ".mid", savedialog.FileName);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Shadows[0] = (System.Windows.Media.Effects.Effect)this.FindResource("z-depth1");
            Shadows[1] = (System.Windows.Media.Effects.Effect)this.FindResource("z-depth2");
            Shadows[2] = (System.Windows.Media.Effects.Effect)this.FindResource("z-depth3");
            Shadows[3] = (System.Windows.Media.Effects.Effect)this.FindResource("z-depth4");
            Shadows[4] = (System.Windows.Media.Effects.Effect)this.FindResource("z-depth5");

            Load_Templates();
        }

        public void Fade_Out_All_Subjects()
        {
            Main_Window_Grid.IsEnabled = false;
            //All_Subjects_Panel.
            ThicknessAnimation ta = new ThicknessAnimation();
            //your first place
            ta.From = Main_Window_Grid.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            ta.To = new Thickness(1500, 0, 0, 0);
            //time the animation playes
            ta.Duration = new Duration(TimeSpan.FromSeconds(0.2));
            //dont need to use story board but if you want pause,stop etc use story board
            Main_Window_Grid.BeginAnimation(Grid.MarginProperty, ta);
        }

        public void Fade_In_All_Subjects()
        {
            Main_Window_Grid.IsEnabled = true;
            //All_Subjects_Panel.
            ThicknessAnimation ta = new ThicknessAnimation();
            //your first place
            ta.From = Main_Window_Grid.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            ta.To = new Thickness(0, 0, 0, 0);
            //time the animation playes
            ta.Duration = new Duration(TimeSpan.FromSeconds(0.2));
            //dont need to use story board but if you want pause,stop etc use story board
            Main_Window_Grid.BeginAnimation(Grid.MarginProperty, ta);
        }

        public void Fade_In_Subject_Grid()
        {
            //Border Height
            DoubleAnimation myDoubleAnimation = new DoubleAnimation();
            myDoubleAnimation.From = MainBorder.Height;
            myDoubleAnimation.To = 161;
            myDoubleAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.25));
            MainBorder.BeginAnimation(Border.HeightProperty, myDoubleAnimation);

  
            //All_Subjects_Panel.
            ThicknessAnimation ta = new ThicknessAnimation();
            //your first place
            ta.From = Single_Template_Grid.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            ta.To = new Thickness(0, 0, 0, 0);
            //time the animation playes
            ta.Duration = new Duration(TimeSpan.FromSeconds(0.2));
            //dont need to use story board but if you want pause,stop etc use story board
            Single_Template_Grid.BeginAnimation(Grid.MarginProperty, ta);

            Back_Button.Content = "<";

        }

        public void Fade_Out_Subject_Grid()
        {

            //Border Height
            DoubleAnimation myDoubleAnimation = new DoubleAnimation();
            myDoubleAnimation.From = MainBorder.Height;
            myDoubleAnimation.To = 41;
            myDoubleAnimation.Duration = new Duration(TimeSpan.FromSeconds(0.25));
            MainBorder.BeginAnimation(Border.HeightProperty, myDoubleAnimation);

            //All_Subjects_Panel.
            ThicknessAnimation ta = new ThicknessAnimation();
            //your first place
            ta.From = Single_Template_Grid.Margin;
            //this move your grid 1000 over from left side
            //you can use -1000 to move to left side
            ta.To = new Thickness(-1500, 0, 0, 0);
            //time the animation playes
            ta.Duration = new Duration(TimeSpan.FromSeconds(0.2));
            //dont need to use story board but if you want pause,stop etc use story board
            Single_Template_Grid.BeginAnimation(Grid.MarginProperty, ta);
        }

        public void Load_Templates()
        {
            // Get the object used to communicate with the server.
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/");
            request.Method = WebRequestMethods.Ftp.ListDirectory;

            // This example assumes the FTP site uses anonymous logon.
            request.Credentials = new NetworkCredential("anonymous", "beta-02");
            try
            {
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                StreamReader streamReader = new StreamReader(response.GetResponseStream());

                string line = streamReader.ReadLine();
                while (!string.IsNullOrEmpty(line))
                {
                    new Template_Element(All_Templates_Panel, line, ref Single_Template_Grid);
                    line = streamReader.ReadLine();
                }
                streamReader.Close();


                response.Close();
            }
            catch (Exception)
            { MessageBox.Show("Could not Load Templates"); }
        }

        private void Exit_Button(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            Fade_Out_Subject_Grid();
            Fade_In_All_Subjects();
            wmp.controls.stop();
            Play.Content = "Play";
            Play.IsEnabled = false;
            Save.IsEnabled = false;
        }

        private void inspiration_button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Midi Files (*.mid, *.midi)|*.mid;*.midi";
            if(dialog.ShowDialog() == true)
            {
                inspiration_path.Text = dialog.FileName;
            }
        }

        private void Inspiration_enabled_Checked(object sender, RoutedEventArgs e)
        {
            if(inspiration_path.Text == "")
            {
                inspiration_button_Click(sender, e);
            }
        }
    }

    public class Template_Element
    {
        static BrushConverter Brushc = new BrushConverter();
        static bool[] Color_used = { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
        public static Brush[] Material_Colors = {
                                                    (Brush)Brushc.ConvertFrom("#f44336"),
                                                    (Brush)Brushc.ConvertFrom("#e91e63"),
                                                    (Brush)Brushc.ConvertFrom("#9c27b0"),
                                                    (Brush)Brushc.ConvertFrom("#673ab7"),
                                                    (Brush)Brushc.ConvertFrom("#3f51b5"),
                                                    (Brush)Brushc.ConvertFrom("#2196f3"),
                                                    (Brush)Brushc.ConvertFrom("#03a9f4"),
                                                    (Brush)Brushc.ConvertFrom("#00bcd4"),
                                                    (Brush)Brushc.ConvertFrom("#009688"),
                                                    (Brush)Brushc.ConvertFrom("#4caf50"),
                                                    (Brush)Brushc.ConvertFrom("#8bc34a"),
                                                    (Brush)Brushc.ConvertFrom("#cddc39"),
                                                    (Brush)Brushc.ConvertFrom("#ffeb3b"),
                                                    (Brush)Brushc.ConvertFrom("#ffc107"),
                                                    (Brush)Brushc.ConvertFrom("#ff9800"),
                                                    (Brush)Brushc.ConvertFrom("#ff5722"),
                                                    (Brush)Brushc.ConvertFrom("#795548"),

                                                };
        public static Brush[] Material_Colors_highlighted = {
                                                    (Brush)Brushc.ConvertFrom("#d32f2f"),
                                                    (Brush)Brushc.ConvertFrom("#c2185b"),
                                                    (Brush)Brushc.ConvertFrom("#7b1fa2"),
                                                    (Brush)Brushc.ConvertFrom("#512da8"),
                                                    (Brush)Brushc.ConvertFrom("#303f9f"),
                                                    (Brush)Brushc.ConvertFrom("#1976d2"),
                                                    (Brush)Brushc.ConvertFrom("#0288d1"),
                                                    (Brush)Brushc.ConvertFrom("#0097a7"),
                                                    (Brush)Brushc.ConvertFrom("#00796b"),
                                                    (Brush)Brushc.ConvertFrom("#388e3c"),
                                                    (Brush)Brushc.ConvertFrom("#689f38"),
                                                    (Brush)Brushc.ConvertFrom("#afb42b"),
                                                    (Brush)Brushc.ConvertFrom("#fbc02d"),
                                                    (Brush)Brushc.ConvertFrom("#ffa000"),
                                                    (Brush)Brushc.ConvertFrom("#f57c00"),
                                                    (Brush)Brushc.ConvertFrom("#e64a19"),
                                                    (Brush)Brushc.ConvertFrom("#5d4037"),
                                                            };

        public Grid grid;
        public Image Content;
        public string Full_Name;
        public int Highlighted_Colorindex;
        public Grid SubjectGrid;
        public Border Classmate_Border;
        public Label Description;

        public Template_Element(WrapPanel Parent, string FullName, ref Grid Subjectgrid)
        {

            Full_Name = FullName;
            SubjectGrid = Subjectgrid;
            grid = new Grid();
            grid.Width = 116;
            grid.Height = 116;
            Parent.Children.Add(grid);


            grid.Background = Pick_unique_Color();
            grid.Effect = MainWindow.Shadows[0];
            grid.MouseEnter += Highlight;
            grid.MouseLeave += Downlight;
            grid.MouseDown += Open_Subject_Tab;

            Get_Subject_Info();

            Content = new Image();
            Content.Source = new BitmapImage(new Uri(System.AppDomain.CurrentDomain.BaseDirectory + FullName + ".png"));
            Content.Width = 64;
            Content.Height = 64;
            Content.Margin = new Thickness(0, 12, 0, 0);
            Content.HorizontalAlignment = HorizontalAlignment.Center;
            Content.VerticalAlignment = VerticalAlignment.Top;
            grid.Children.Add(Content);

            Description = new Label();
            Description.HorizontalAlignment = HorizontalAlignment.Center;
            Description.VerticalAlignment = VerticalAlignment.Bottom;
            Description.HorizontalContentAlignment = HorizontalAlignment.Center;
            Description.VerticalContentAlignment = VerticalAlignment.Center;
            Description.Content = Full_Name;
            Description.FontSize = 15;
            Description.Foreground = Brushes.White;
            grid.Children.Add(Description);


            Canvas.SetZIndex(Content, 3);
        }

        private void Highlight(object sender, MouseEventArgs e)
        {
            Grid button = (Grid)sender;
            //var bc = new BrushConverter();
            //button.Effect = MainWindow.Shadows[2];
            button.Background = Material_Colors_highlighted[Array.IndexOf(Material_Colors, button.Background)];
        }

        private void Get_Subject_Info()
        {
            // Get the object used to communicate with the server.
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://193.170.162.110/" + Full_Name + "/icon.png");
            request.Method = WebRequestMethods.Ftp.DownloadFile;

            // This example assumes the FTP site uses anonymous logon.
            request.Credentials = new NetworkCredential("anonymous", "beta-01");
            try
            {
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                Stream reader = response.GetResponseStream();
                FileStream fileStream = new FileStream(Full_Name + ".png", FileMode.Create);
                int bytesRead = 0;
                byte[] buffer = new byte[2048];
                while (true)
                {
                    bytesRead = reader.Read(buffer, 0, buffer.Length);

                    if (bytesRead == 0)
                        break;

                    fileStream.Write(buffer, 0, bytesRead);
                }
                fileStream.Close();

                Console.WriteLine("Download Complete, status {0}", response.StatusDescription);

                reader.Close();
                response.Close();
            }
            catch (Exception)
            { MessageBox.Show("Error! Could not Load Icon for: " + Full_Name); }
        }

        private void Downlight(object sender, MouseEventArgs e)
        {
            Grid button = (Grid)sender;
            // var bc = new BrushConverter();
            button.Effect = MainWindow.Shadows[0];
            button.Background = Material_Colors[Array.IndexOf(Material_Colors_highlighted, button.Background)];
        }

        private void Open_Subject_Tab(object sender, MouseEventArgs e)
        {
            Border subjectborder = (Border)SubjectGrid.Children[0];
            Grid senderborder = (Grid)sender;
            //subjectborder.Background = Material_Colors[Array.IndexOf(Material_Colors_highlighted, senderborder.Background)];

            Image senderlogo = (Image)senderborder.Children[0];
            Image subjectlogo = (Image)subjectborder.Child;
            subjectlogo.Source = senderlogo.Source;

            Label fullsubjectlabel = (Label)SubjectGrid.Children[1];
            fullsubjectlabel.Content = this.Full_Name;

            ((MainWindow)System.Windows.Application.Current.MainWindow).Fade_Out_All_Subjects();
            ((MainWindow)System.Windows.Application.Current.MainWindow).Fade_In_Subject_Grid();

        }

        private Brush Pick_unique_Color()
        {
            int index = 0;
            do
            {
                index = new Random().Next(0, Material_Colors.Length);

            } while (Color_used[index]);

            this.Highlighted_Colorindex = index;
            Color_used[index] = true;

            return Material_Colors[index];

        }

    }
}
